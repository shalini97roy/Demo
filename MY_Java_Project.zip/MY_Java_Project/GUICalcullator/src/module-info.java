/**
 * 
 */
/**
 * 
 */
module GUICalcullator {
	requires java.desktop;
}