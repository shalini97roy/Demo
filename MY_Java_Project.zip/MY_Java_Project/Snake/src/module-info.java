/**
 * 
 */
/**
 * 
 */
module Snake {
	requires java.desktop;
}