/**
 * 
 */
/**
 * 
 */
module SimpleGame {
}