/**
 * 
 */
/**
 * 
 */
module Clock {
	requires java.desktop;
}