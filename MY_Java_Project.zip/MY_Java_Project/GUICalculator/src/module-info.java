/**
 * 
 */
/**
 * 
 */
module GUICalculator {
	requires java.desktop;
}