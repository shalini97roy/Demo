/**
 * 
 */
/**
 * 
 */
module CGUICalculator {
}